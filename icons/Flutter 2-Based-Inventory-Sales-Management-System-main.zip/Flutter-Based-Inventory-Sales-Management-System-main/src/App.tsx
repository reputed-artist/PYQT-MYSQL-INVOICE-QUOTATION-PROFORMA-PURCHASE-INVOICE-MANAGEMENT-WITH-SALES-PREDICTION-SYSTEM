import React from 'react';
import { InventoryProvider, useInventory } from './context/InventoryContext';
import { Header } from './components/Header';
import { BottomNav } from './components/BottomNav';
import { InventoryView } from './components/InventoryView';
import { ReportsView } from './components/ReportsView';
import { AuditLogView } from './components/AuditLogView';
import { QuickActionModal } from './components/QuickActionModal';
import { ItemDetailModal } from './components/ItemDetailModal';
import { BarcodeScannerModal } from './components/BarcodeScannerModal';
import { UserSwitcherModal } from './components/UserSwitcherModal';
import { SupabaseSettingsModal } from './components/SupabaseSettingsModal';
import { FlutterCodeModal } from './components/FlutterCodeModal';
import { usePWAInstall } from './hooks/usePWAInstall';
import { Download, X } from 'lucide-react';
import { sound } from './lib/sound';

const AppContent: React.FC = () => {
  const { activeTab, flutterCodeModalOpen, setFlutterCodeModalOpen, toast, dismissToast } = useInventory();
  const { isInstallable, install, isInstalled } = usePWAInstall();
  const [installDismissed, setInstallDismissed] = React.useState(false);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-blue-500 selection:text-white">
      {/* PWA Install Banner for Android */}
      {isInstallable && !installDismissed && !isInstalled && (
        <div className="bg-gradient-to-r from-blue-700 via-indigo-600 to-blue-800 text-white px-4 py-2.5 text-xs flex items-center justify-between shadow-md border-b border-blue-500/40 animate-in slide-in-from-top duration-300">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-white/20 flex items-center justify-center font-bold">
              📦
            </div>
            <div>
              <p className="font-bold leading-tight">Install Android App</p>
              <p className="text-[11px] text-blue-100">Add to Home Screen for offline scanning & fast access</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                sound.playClick();
                install();
              }}
              className="px-3 py-1.5 rounded-lg bg-white text-blue-700 font-bold text-xs shadow hover:bg-blue-50 transition active:scale-95 flex items-center gap-1"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Install</span>
            </button>
            <button
              onClick={() => setInstallDismissed(true)}
              className="p-1 rounded-md text-blue-200 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Main Top Header */}
      <Header />

      {/* Main Scrollable Canvas */}
      <main className="flex-1 max-w-5xl w-full mx-auto p-3 sm:p-5">
        {activeTab === 'inventory' && <InventoryView />}
        {activeTab === 'reports' && <ReportsView />}
        {activeTab === 'activity' && <AuditLogView />}
      </main>

      {/* Bottom Navigation for Android PWA */}
      <BottomNav />

      {/* Floating Feedback Toast for Android & Web */}
      {toast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 w-11/12 max-w-md animate-in slide-in-from-top-4 fade-in duration-200">
          <div
            className={`px-4 py-3 rounded-2xl shadow-2xl border flex items-center justify-between gap-3 text-sm font-semibold backdrop-blur-md ${
              toast.type === 'success'
                ? 'bg-emerald-950/95 border-emerald-500/60 text-emerald-100 shadow-emerald-950/50'
                : toast.type === 'error'
                ? 'bg-rose-950/95 border-rose-500/60 text-rose-100 shadow-rose-950/50'
                : toast.type === 'warning'
                ? 'bg-amber-950/95 border-amber-500/60 text-amber-100 shadow-amber-950/50'
                : 'bg-blue-950/95 border-blue-500/60 text-blue-100 shadow-blue-950/50'
            }`}
          >
            <div className="flex items-center gap-2.5 min-w-0">
              <span className="w-2 h-2 rounded-full bg-current animate-pulse flex-shrink-0" />
              <span className="truncate">{toast.message}</span>
            </div>
            <button
              onClick={() => {
                sound.playClick();
                dismissToast();
              }}
              className="p-1 rounded-lg text-white/70 hover:text-white hover:bg-white/10 transition flex-shrink-0"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Modals */}
      <QuickActionModal />
      <ItemDetailModal />
      <BarcodeScannerModal />
      <UserSwitcherModal />
      <SupabaseSettingsModal />
      <FlutterCodeModal
        isOpen={flutterCodeModalOpen}
        onClose={() => setFlutterCodeModalOpen(false)}
      />
    </div>
  );
};

export default function App() {
  return (
    <InventoryProvider>
      <AppContent />
    </InventoryProvider>
  );
}
