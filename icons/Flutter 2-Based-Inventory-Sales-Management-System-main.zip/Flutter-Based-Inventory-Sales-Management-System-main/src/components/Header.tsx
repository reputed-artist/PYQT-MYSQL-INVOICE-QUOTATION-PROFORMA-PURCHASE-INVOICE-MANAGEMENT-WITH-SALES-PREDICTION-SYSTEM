import React from 'react';
import {
  Package,
  QrCode,
  Cloud,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import { sound } from '../lib/sound';

export const Header: React.FC = () => {
  const {
    currentOperator,
    syncStatus,
    setScannerModalOpen,
    setUserSwitcherModalOpen,
    setSupabaseSettingsModalOpen,
    syncWithSupabase,
  } = useInventory();

  const [soundEnabled, setSoundEnabled] = React.useState(true);

  const toggleSound = () => {
    const next = !soundEnabled;
    setSoundEnabled(next);
    sound.enabled = next;
    if (next) sound.playClick();
  };

  return (
    <header className="sticky top-0 z-30 bg-[#111827] border-b border-[#1E293B] px-3.5 py-3">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-2">
        {/* Left: App Icon & Title */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-[#0284C7]/15 border border-[#0284C7]/30 flex items-center justify-center text-[#38BDF8] flex-shrink-0 shadow-sm">
            <Package className="w-5 h-5 text-[#38BDF8]" />
          </div>
          <div>
            <h1 className="text-base font-bold text-white tracking-tight leading-none">
              Ink & Machine Sync
            </h1>
            <div className="flex items-center gap-1.5 mt-1">
              <span className={`w-1.5 h-1.5 rounded-full ${syncStatus === 'synced' ? 'bg-[#10B981]' : 'bg-[#F59E0B]'}`} />
              <span className="text-[11px] text-slate-400 font-medium">
                {syncStatus === 'synced' ? 'Supabase Live' : 'Offline / Local Sync'}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Scanner, Supabase, Operator Avatar */}
        <div className="flex items-center gap-2">
          {/* Barcode Scanner */}
          <button
            onClick={() => {
              sound.playScan();
              setScannerModalOpen(true);
            }}
            title="Open Barcode Scanner"
            className="p-1.5 rounded-lg text-[#38BDF8] hover:bg-slate-800 transition active:scale-95"
          >
            <QrCode className="w-5 h-5 text-[#38BDF8]" />
          </button>

          {/* Supabase Cloud */}
          <button
            onClick={() => {
              sound.playClick();
              setSupabaseSettingsModalOpen(true);
            }}
            title="Supabase Cloud Config"
            className="p-1.5 rounded-lg text-[#10B981] hover:bg-slate-800 transition active:scale-95"
          >
            <Cloud className="w-5 h-5 text-[#10B981]" />
          </button>

          {/* Sound Toggle (small) */}
          <button
            onClick={toggleSound}
            title={soundEnabled ? 'Sound On' : 'Sound Muted'}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 transition hidden sm:inline-block"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Operator Pill */}
          <button
            onClick={() => {
              sound.playClick();
              setUserSwitcherModalOpen(true);
            }}
            className="flex items-center gap-2 py-1 px-2.5 rounded-full bg-[#1E293B] border border-[#334155] hover:bg-[#283548] transition active:scale-95 text-left cursor-pointer"
            title={`Operator: ${currentOperator.name}. Click to switch.`}
          >
            <div
              className="w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold text-white flex-shrink-0"
              style={{ backgroundColor: currentOperator.avatarColor || '#0284c7' }}
            >
              {currentOperator.name.charAt(0)}
            </div>
            <span className="text-xs text-white font-medium">
              {currentOperator.name.split(' ')[0]}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
