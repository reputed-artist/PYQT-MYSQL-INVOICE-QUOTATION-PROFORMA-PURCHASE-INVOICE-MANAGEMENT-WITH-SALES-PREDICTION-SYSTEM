import React, { useMemo, useState } from 'react';
import {
  Search,
  Plus,
  AlertTriangle,
  PackagePlus,
  Layers,
  MapPin,
  TrendingUp,
  QrCode,
  ClipboardCheck,
  ShoppingCart,
  TrendingDown,
  Cloud,
  Database,
  RefreshCw,
  CheckCircle2,
} from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import { CATEGORIES } from '../data/initialData';
import { InventoryCategory } from '../types';
import { sound } from '../lib/sound';

export const InventoryView: React.FC = () => {
  const {
    items,
    selectedCategory,
    setSelectedCategory,
    searchQuery,
    setSearchQuery,
    openQuickAction,
    setDetailModalItem,
    setScannerModalOpen,
    cloudDiagnostic,
    syncStatus,
    lastSyncTime,
    syncWithSupabase,
    setSupabaseSettingsModalOpen,
    operators,
  } = useInventory();

  const [isSyncingLive, setIsSyncingLive] = useState(false);
  const [showLowStockOnly, setShowLowStockOnly] = useState(false);

  // Compute stats
  const stats = useMemo(() => {
    const totalItems = items.length;
    const lowStockItems = items.filter(i => i.leftCount <= i.minStockAlert).length;
    const totalUnitsLeft = items.reduce((acc, curr) => acc + curr.leftCount, 0);
    const totalUnitsSold = items.reduce((acc, curr) => acc + curr.totalSold, 0);
    const totalInventoryValue = items.reduce((acc, curr) => acc + (curr.leftCount * curr.unitCostPrice), 0);

    return { totalItems, lowStockItems, totalUnitsLeft, totalUnitsSold, totalInventoryValue };
  }, [items]);

  // Filtered items
  const filteredItems = useMemo(() => {
    return items.filter((item) => {
      // Category filter
      if (selectedCategory !== 'all' && item.category !== selectedCategory) {
        return false;
      }
      // Low stock filter
      if (showLowStockOnly && item.leftCount > item.minStockAlert) {
        return false;
      }
      // Search filter
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchName = item.name.toLowerCase().includes(q);
        const matchSku = item.sku.toLowerCase().includes(q);
        const matchLocation = item.location?.toLowerCase().includes(q) || false;
        const matchBarcode = item.barcode?.toLowerCase().includes(q) || false;
        return matchName || matchSku || matchLocation || matchBarcode;
      }
      return true;
    });
  }, [items, selectedCategory, showLowStockOnly, searchQuery]);

  const getCategoryMeta = (catId: InventoryCategory) => {
    return CATEGORIES.find(c => c.id === catId) || CATEGORIES[0];
  };

  const getCategoryCount = (catId: 'all' | InventoryCategory) => {
    if (catId === 'all') return items.length;
    return items.filter(i => i.category === catId).length;
  };

  return (
    <div className="space-y-3.5 pb-24">
      {/* 2x2 Metric Cards Grid */}
      <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
        {/* Card 1: Stock Left */}
        <div className="bg-[#161F30] border border-[#26334D] rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">STOCK LEFT</span>
            <Layers className="w-4 h-4 text-[#38BDF8]" />
          </div>
          <p className="text-2xl font-black text-[#38BDF8] mt-1.5 leading-none">
            {stats.totalUnitsLeft}
          </p>
          <p className="text-xs text-slate-400 mt-1.5">Units available</p>
        </div>

        {/* Card 2: Units Sold */}
        <div className="bg-[#161F30] border border-[#26334D] rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">UNITS SOLD</span>
            <TrendingUp className="w-4 h-4 text-[#10B981]" />
          </div>
          <p className="text-2xl font-black text-[#10B981] mt-1.5 leading-none">
            {stats.totalUnitsSold}
          </p>
          <p className="text-xs text-slate-400 mt-1.5">Total dispatched</p>
        </div>

        {/* Card 3: Low Stock Alert (Red Outline) */}
        <button
          onClick={() => {
            sound.playClick();
            setShowLowStockOnly(prev => !prev);
          }}
          className={`bg-[#161F30] rounded-2xl p-3.5 shadow-sm text-left transition cursor-pointer border ${
            showLowStockOnly
              ? 'border-red-500 bg-red-950/20'
              : stats.lowStockItems > 0
              ? 'border-[#EF4444]/60 hover:border-red-500'
              : 'border-[#26334D]'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">LOW STOCK ALERT</span>
            <AlertTriangle className="w-4 h-4 text-[#EF4444]" />
          </div>
          <p className="text-2xl font-black text-[#EF4444] mt-1.5 leading-none">
            {stats.lowStockItems}
          </p>
          <p className="text-xs text-slate-400 mt-1.5">
            {showLowStockOnly ? 'Tap to clear filter' : 'Requires reorder'}
          </p>
        </button>

        {/* Card 4: Stock Value */}
        <div className="bg-[#161F30] border border-[#26334D] rounded-2xl p-3.5 shadow-sm">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">STOCK VALUE</span>
            <span className="text-base font-bold text-[#F59E0B]">₹</span>
          </div>
          <p className="text-2xl font-black text-[#F59E0B] mt-1.5 leading-none">
            ₹{Math.round(stats.totalInventoryValue).toLocaleString('en-IN')}
          </p>
          <p className="text-xs text-slate-400 mt-1.5">Cost valuation</p>
        </div>
      </div>

      {/* Supabase Cloud Live Status & Connectivity Bar */}
      <div className="bg-[#111A2C] border border-[#1E293B] rounded-2xl p-3 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400 flex-shrink-0">
            <Database className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                Supabase Cloud Connected
              </span>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 border border-slate-700 font-mono">
                edkeoeevdldytggiisxb.supabase.co
              </span>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Live operators synced: <strong className="text-slate-200">{operators.length} active</strong> ({operators.map(o => o.name.split(' ')[0]).join(', ')})
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          {cloudDiagnostic.rlsRestricted && (
            <button
              type="button"
              onClick={() => {
                sound.playClick();
                setSupabaseSettingsModalOpen(true);
              }}
              className="text-[11px] px-2.5 py-1 rounded-lg bg-amber-500/15 border border-amber-500/30 text-amber-300 hover:bg-amber-500/25 transition cursor-pointer flex items-center gap-1"
              title="Cloud RLS Policy Notice"
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              <span>RLS 1-Click Fix</span>
            </button>
          )}

          <button
            type="button"
            onClick={async () => {
              sound.playClick();
              setIsSyncingLive(true);
              await syncWithSupabase();
              setIsSyncingLive(false);
              sound.playSuccess();
            }}
            disabled={isSyncingLive}
            className="text-xs px-3 py-1.5 rounded-xl bg-[#1E293B] hover:bg-[#283548] border border-[#334155] text-slate-200 transition active:scale-95 cursor-pointer flex items-center gap-1.5 font-medium"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-emerald-400 ${isSyncingLive ? 'animate-spin' : ''}`} />
            <span>{isSyncingLive ? 'Syncing...' : 'Sync Supabase'}</span>
          </button>
        </div>
      </div>

      {/* Full-width Search Bar with Barcode Scanner Button */}
      <div className="relative">
        <div className="w-full flex items-center bg-[#161F30] border border-[#26334D] rounded-xl px-3.5 py-3">
          <Search className="w-4 h-4 text-[#94A3B8] flex-shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search SKU, HP Cartridge, Docod, Ryna..."
            className="w-full bg-transparent border-none pl-3 pr-2 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-slate-400 hover:text-white text-xs px-1 mr-1 cursor-pointer"
            >
              ✕
            </button>
          )}
          <button
            onClick={() => {
              sound.playScan();
              setScannerModalOpen(true);
            }}
            className="text-[#38BDF8] hover:text-sky-300 transition cursor-pointer p-0.5"
            title="Scan Barcode / QR"
          >
            <QrCode className="w-5 h-5 text-[#38BDF8]" />
          </button>
        </div>
      </div>

      {/* Category Chips (Horizontal Scroll) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar -mx-1 px-1">
        <button
          onClick={() => {
            sound.playClick();
            setSelectedCategory('all');
          }}
          className={`px-4 py-2 rounded-full text-xs transition-all whitespace-nowrap cursor-pointer ${
            selectedCategory === 'all'
              ? 'bg-[#0284C7] text-white font-bold shadow-sm shadow-sky-600/30'
              : 'bg-[#1E293B] text-slate-300 font-medium hover:text-white border border-[#334155]'
          }`}
        >
          All Items ({items.length})
        </button>

        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          const count = getCategoryCount(cat.id);
          return (
            <button
              key={cat.id}
              onClick={() => {
                sound.playClick();
                setSelectedCategory(cat.id);
              }}
              className={`px-4 py-2 rounded-full text-xs transition-all whitespace-nowrap cursor-pointer ${
                isSelected
                  ? 'bg-[#0284C7] text-white font-bold shadow-sm shadow-sky-600/30'
                  : 'bg-[#1E293B] text-slate-300 font-medium hover:text-white border border-[#334155]'
              }`}
            >
              {cat.name} ({count})
            </button>
          );
        })}
      </div>

      {/* Catalog Section Header */}
      <div className="flex items-center justify-between px-1 pt-1">
        <span className="text-[11px] font-bold tracking-wider text-[#94A3B8] uppercase">
          INVENTORY CATALOG ({filteredItems.length})
        </span>
        {showLowStockOnly && (
          <button
            onClick={() => {
              sound.playClick();
              setShowLowStockOnly(false);
            }}
            className="text-[11px] font-bold text-[#38BDF8] hover:underline cursor-pointer"
          >
            Clear Low Stock Filter
          </button>
        )}
      </div>

      {/* Inventory Item Cards */}
      <div className="space-y-3">
        {filteredItems.length === 0 ? (
          <div className="bg-[#161F30] border border-dashed border-[#26334D] rounded-2xl p-8 text-center">
            <PackagePlus className="w-12 h-12 text-slate-500 mx-auto mb-3 opacity-60" />
            <h3 className="text-base font-semibold text-slate-200">No inventory items found</h3>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              {showLowStockOnly
                ? 'Great news! There are currently no items under the low-stock alert threshold.'
                : 'Try adjusting your search query, clearing filters, or adding a new item.'}
            </p>
            <div className="flex items-center justify-center gap-2 mt-4">
              {showLowStockOnly && (
                <button
                  onClick={() => setShowLowStockOnly(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-700 text-slate-200 text-xs font-medium hover:bg-slate-600 cursor-pointer"
                >
                  Clear Low Stock Filter
                </button>
              )}
              <button
                onClick={() => openQuickAction('NEW_ITEM')}
                className="px-3.5 py-1.5 rounded-lg bg-[#0284C7] text-white text-xs font-medium hover:bg-sky-600 cursor-pointer"
              >
                + Add New Inventory Item
              </button>
            </div>
          </div>
        ) : (
          filteredItems.map((item) => {
            const cat = getCategoryMeta(item.category);
            const isLowStock = item.leftCount <= item.minStockAlert;
            const isOutOfStock = item.leftCount <= 0;

            return (
              <div
                key={item.id}
                className={`bg-[#161F30] border rounded-2xl p-4 transition-all shadow-sm ${
                  isOutOfStock
                    ? 'border-rose-500/60'
                    : isLowStock
                    ? 'border-amber-500/50'
                    : 'border-[#26334D]'
                }`}
              >
                {/* Header: Category Badge & SKU */}
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold px-2.5 py-0.5 rounded-md bg-[#0284C7]/15 text-[#38BDF8]">
                    {cat.name}
                  </span>
                  <span className="font-mono text-xs font-semibold text-[#94A3B8]">
                    {item.sku}
                  </span>
                </div>

                {/* Item Name & Location */}
                <div
                  className="mt-2 cursor-pointer group"
                  onClick={() => {
                    sound.playClick();
                    setDetailModalItem(item);
                  }}
                >
                  <h3 className="text-base font-bold text-white leading-snug group-hover:text-sky-400 transition">
                    {item.name}
                  </h3>
                  {item.location && (
                    <p className="text-xs text-[#94A3B8] flex items-center gap-1 mt-1">
                      <MapPin className="w-3.5 h-3.5 text-[#94A3B8] flex-shrink-0" />
                      <span>{item.location}</span>
                    </p>
                  )}
                </div>

                {/* Stock Counters Box (TOTAL IN, SOLD, LEFT COUNT) */}
                <div className="bg-[#0B111E] border border-[#1E293B] rounded-xl py-3 px-2 my-3">
                  <div className="grid grid-cols-3 divide-x divide-[#1E293B] text-center">
                    {/* TOTAL IN */}
                    <div className="px-1 flex flex-col items-center justify-center">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        TOTAL IN
                      </span>
                      <span className="text-base font-bold text-white mt-1 leading-tight">
                        {item.totalIn}
                      </span>
                    </div>

                    {/* SOLD */}
                    <div className="px-1 flex flex-col items-center justify-center">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        SOLD
                      </span>
                      <span className="text-base font-bold text-[#10B981] mt-1 leading-tight">
                        {item.totalSold}
                      </span>
                    </div>

                    {/* LEFT COUNT */}
                    <div className="px-1 flex flex-col items-center justify-center">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        LEFT COUNT
                      </span>
                      <span
                        className={`text-lg font-black mt-1 leading-tight ${
                          isOutOfStock
                            ? 'text-[#EF4444]'
                            : isLowStock
                            ? 'text-[#F59E0B]'
                            : 'text-[#38BDF8]'
                        }`}
                      >
                        {item.leftCount}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Action Buttons: Add In, Sold Out, Audit */}
                <div className="flex items-center gap-2">
                  {/* Add In Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      sound.playClick();
                      openQuickAction('STOCK_IN', item);
                    }}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-[#0284C7] hover:bg-[#0369a1] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition active:scale-95 cursor-pointer"
                    title={`Add stock for ${item.name}`}
                  >
                    <ShoppingCart className="w-4 h-4" />
                    <span>Add In</span>
                  </button>

                  {/* Sold Out Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      sound.playClick();
                      openQuickAction('SOLD', item);
                    }}
                    className="flex-1 py-2.5 px-3 rounded-xl bg-[#059669] hover:bg-[#047857] text-white font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition active:scale-95 cursor-pointer"
                    title={`Record sold out for ${item.name}`}
                  >
                    <TrendingDown className="w-4 h-4" />
                    <span>Sold Out</span>
                  </button>

                  {/* Audit Button */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      sound.playClick();
                      openQuickAction('COUNT_UPDATE', item);
                    }}
                    className="py-2.5 px-3 rounded-xl bg-[#1E293B] hover:bg-[#283548] border border-[#334155] text-[#F59E0B] flex items-center justify-center shadow-sm transition active:scale-95 cursor-pointer"
                    title={`Physical count audit for ${item.name}`}
                  >
                    <ClipboardCheck className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Floating "Add New Item" Button (as in image) */}
      <div className="fixed bottom-20 right-4 z-40 sm:bottom-24 sm:right-6">
        <button
          type="button"
          onClick={() => {
            sound.playClick();
            openQuickAction('NEW_ITEM');
          }}
          className="flex items-center gap-1.5 px-4 py-3 rounded-2xl bg-[#0284C7] hover:bg-[#0369a1] text-white font-bold text-sm shadow-xl shadow-sky-950/60 active:scale-95 transition cursor-pointer"
        >
          <Plus className="w-5 h-5 stroke-[2.5]" />
          <span>Add New Item</span>
        </button>
      </div>
    </div>
  );
};
