import React from 'react';
import {
  Package,
  BarChart2,
  ScrollText,
} from 'lucide-react';
import { useInventory } from '../context/InventoryContext';
import { sound } from '../lib/sound';
import { ActiveTab } from '../types';

export const BottomNav: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
  } = useInventory();

  const handleTabSelect = (tab: ActiveTab) => {
    sound.playClick();
    setActiveTab(tab);
  };

  const navItems = [
    { id: 'inventory' as ActiveTab, label: 'Stock Items', icon: Package },
    { id: 'reports' as ActiveTab, label: 'Reports', icon: BarChart2 },
    { id: 'activity' as ActiveTab, label: 'Audit Log', icon: ScrollText },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-[#0F172A] border-t border-[#1E293B] pb-safe">
      <div className="max-w-md md:max-w-xl mx-auto flex items-center justify-around px-4 py-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;

          return (
            <button
              key={item.id}
              onClick={() => handleTabSelect(item.id)}
              className={`flex flex-col items-center justify-center py-1 px-4 rounded-xl transition-all relative cursor-pointer ${
                isActive
                  ? 'text-[#38BDF8] font-bold'
                  : 'text-[#94A3B8] hover:text-slate-200 font-medium'
              }`}
            >
              <div className={`p-1 rounded-xl transition-all ${isActive ? 'bg-[#0284C7]/20 text-[#38BDF8]' : ''}`}>
                <Icon className={`w-5 h-5 transition-transform ${isActive ? 'scale-105 stroke-[2.2]' : 'stroke-[1.8]'}`} />
              </div>
              <span className={`text-[11px] mt-0.5 tracking-tight ${isActive ? 'text-[#38BDF8] font-bold' : 'text-[#94A3B8]'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
