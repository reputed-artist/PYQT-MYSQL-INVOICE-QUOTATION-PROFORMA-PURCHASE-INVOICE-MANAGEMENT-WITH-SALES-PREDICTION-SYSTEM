package com.example.ink_inventory_sync

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
